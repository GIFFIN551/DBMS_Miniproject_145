-- ============================================
-- Crime Guard MySQL Query Reference
-- ============================================
-- This file contains common SQL queries used in the Crime Guard system

-- ============================================
-- 1. USER MANAGEMENT QUERIES
-- ============================================

-- Get all active users
SELECT id, email, full_name, role, created_at 
FROM users 
WHERE is_verified = TRUE 
ORDER BY created_at DESC;

-- Get user by email
SELECT * FROM users WHERE email = 'user@example.com';

-- Update user last login
UPDATE users 
SET last_login = CURRENT_TIMESTAMP 
WHERE id = 1;

-- Get officers for assignment
SELECT id, full_name, email 
FROM users 
WHERE role = 'officer' AND is_verified = TRUE;

-- Count users by role
SELECT role, COUNT(*) as total 
FROM users 
GROUP BY role;

-- ============================================
-- 2. CRIME REPORT QUERIES
-- ============================================

-- Get all pending crime reports with details
SELECT 
    cr.id,
    cr.report_number,
    cr.title,
    cr.description,
    cr.status,
    cr.priority,
    cr.incident_date,
    u.full_name as reporter_name,
    cc.name as category_name,
    l.city,
    l.address
FROM crime_reports cr
INNER JOIN users u ON cr.user_id = u.id
INNER JOIN crime_categories cc ON cr.category_id = cc.id
INNER JOIN locations l ON cr.location_id = l.id
WHERE cr.status = 'pending'
ORDER BY cr.priority DESC, cr.reported_date DESC;

-- Get reports by status
SELECT status, COUNT(*) as count 
FROM crime_reports 
GROUP BY status;

-- Get high priority unresolved cases
SELECT 
    report_number,
    title,
    priority,
    incident_date,
    DATEDIFF(CURRENT_DATE, DATE(reported_date)) as days_open
FROM crime_reports
WHERE status IN ('pending', 'investigating')
    AND priority IN ('high', 'urgent')
ORDER BY priority DESC, incident_date DESC;

-- Update report status
UPDATE crime_reports 
SET status = 'investigating', 
    assigned_officer_id = 2,
    updated_at = CURRENT_TIMESTAMP 
WHERE id = 1;

-- Get reports assigned to specific officer
SELECT 
    cr.report_number,
    cr.title,
    cr.status,
    cr.priority,
    cc.name as category
FROM crime_reports cr
INNER JOIN crime_categories cc ON cr.category_id = cc.id
WHERE cr.assigned_officer_id = 2
    AND cr.status != 'closed'
ORDER BY cr.priority DESC;

-- ============================================
-- 3. LOCATION AND GEOSPATIAL QUERIES
-- ============================================

-- Get crimes by city
SELECT 
    l.city,
    COUNT(cr.id) as total_crimes,
    COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) as resolved_crimes
FROM locations l
INNER JOIN crime_reports cr ON cr.location_id = l.id
GROUP BY l.city
ORDER BY total_crimes DESC;

-- Get crimes within geographical bounds (example coordinates)
SELECT 
    cr.report_number,
    cr.title,
    l.address,
    l.latitude,
    l.longitude
FROM crime_reports cr
INNER JOIN locations l ON cr.location_id = l.id
WHERE l.latitude BETWEEN 40.7000 AND 40.8000
    AND l.longitude BETWEEN -74.0500 AND -73.9500;

-- Find nearest crime reports to a location
SELECT 
    cr.report_number,
    cr.title,
    l.address,
    SQRT(
        POW(69.1 * (l.latitude - 40.7128), 2) +
        POW(69.1 * (-74.0060 - l.longitude) * COS(l.latitude / 57.3), 2)
    ) AS distance_miles
FROM crime_reports cr
INNER JOIN locations l ON cr.location_id = l.id
ORDER BY distance_miles
LIMIT 10;

-- ============================================
-- 4. STATISTICS AND ANALYTICS QUERIES
-- ============================================

-- Get overall crime statistics
SELECT 
    COUNT(*) as total_reports,
    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
    COUNT(CASE WHEN status = 'investigating' THEN 1 END) as investigating,
    COUNT(CASE WHEN status = 'resolved' THEN 1 END) as resolved,
    COUNT(CASE WHEN status = 'closed' THEN 1 END) as closed,
    AVG(CASE 
        WHEN status = 'resolved' AND resolved_date IS NOT NULL 
        THEN TIMESTAMPDIFF(HOUR, reported_date, resolved_date) 
    END) as avg_resolution_hours
FROM crime_reports;

-- Monthly crime trend
SELECT 
    DATE_FORMAT(incident_date, '%Y-%m') as month,
    COUNT(*) as total_reports,
    COUNT(CASE WHEN priority = 'urgent' THEN 1 END) as urgent_cases
FROM crime_reports
WHERE incident_date >= DATE_SUB(CURRENT_DATE, INTERVAL 6 MONTH)
GROUP BY DATE_FORMAT(incident_date, '%Y-%m')
ORDER BY month;

-- Crime category breakdown
SELECT 
    cc.name as category,
    cc.severity_level,
    COUNT(cr.id) as total_reports,
    COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) as resolved,
    ROUND(COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) * 100.0 / COUNT(cr.id), 2) as resolution_rate
FROM crime_categories cc
LEFT JOIN crime_reports cr ON cr.category_id = cc.id
GROUP BY cc.id, cc.name, cc.severity_level
ORDER BY total_reports DESC;

-- Daily statistics for dashboard
SELECT 
    DATE(incident_date) as date,
    COUNT(*) as reports_count,
    COUNT(DISTINCT category_id) as unique_categories,
    COUNT(DISTINCT location_id) as unique_locations
FROM crime_reports
WHERE incident_date >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
GROUP BY DATE(incident_date)
ORDER BY date DESC;

-- ============================================
-- 5. EVIDENCE AND WITNESS QUERIES
-- ============================================

-- Get evidence for a specific report
SELECT 
    e.id,
    e.evidence_type,
    e.file_name,
    e.description,
    e.uploaded_at,
    u.full_name as uploaded_by_name
FROM evidence e
INNER JOIN users u ON e.uploaded_by = u.id
WHERE e.crime_report_id = 1
ORDER BY e.uploaded_at DESC;

-- Count evidence by type
SELECT 
    evidence_type,
    COUNT(*) as total,
    SUM(file_size) as total_size_bytes
FROM evidence
GROUP BY evidence_type;

-- Get witness information for report
SELECT 
    w.full_name,
    w.phone,
    w.email,
    w.contacted,
    w.is_anonymous
FROM witnesses w
WHERE w.crime_report_id = 1;

-- Reports with multiple witnesses
SELECT 
    cr.report_number,
    cr.title,
    COUNT(w.id) as witness_count
FROM crime_reports cr
INNER JOIN witnesses w ON w.crime_report_id = cr.id
GROUP BY cr.id, cr.report_number, cr.title
HAVING COUNT(w.id) > 1
ORDER BY witness_count DESC;

-- ============================================
-- 6. NOTIFICATION QUERIES
-- ============================================

-- Get unread notifications for user
SELECT 
    n.id,
    n.title,
    n.message,
    n.notification_type,
    n.created_at,
    cr.report_number
FROM notifications n
LEFT JOIN crime_reports cr ON n.crime_report_id = cr.id
WHERE n.user_id = 1 
    AND n.is_read = FALSE
ORDER BY n.created_at DESC;

-- Mark notifications as read
UPDATE notifications 
SET is_read = TRUE 
WHERE user_id = 1 AND id IN (1, 2, 3);

-- Get notification count by type
SELECT 
    notification_type,
    COUNT(*) as total,
    COUNT(CASE WHEN is_read = FALSE THEN 1 END) as unread
FROM notifications
WHERE user_id = 1
GROUP BY notification_type;

-- ============================================
-- 7. REPORT UPDATES AND TIMELINE
-- ============================================

-- Get complete timeline for a crime report
SELECT 
    cu.id,
    cu.update_type,
    cu.content,
    cu.is_public,
    cu.created_at,
    u.full_name as updated_by
FROM crime_updates cu
INNER JOIN users u ON cu.user_id = u.id
WHERE cu.crime_report_id = 1
ORDER BY cu.created_at ASC;

-- Add new update to report
INSERT INTO crime_updates (crime_report_id, user_id, update_type, content, is_public)
VALUES (1, 2, 'status_change', 'Case has been assigned to Officer Smith for investigation', TRUE);

-- Get recent activity across all reports
SELECT 
    cu.update_type,
    cu.content,
    cu.created_at,
    cr.report_number,
    u.full_name as officer_name
FROM crime_updates cu
INNER JOIN crime_reports cr ON cu.crime_report_id = cr.id
INNER JOIN users u ON cu.user_id = u.id
WHERE cu.created_at >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 24 HOUR)
ORDER BY cu.created_at DESC
LIMIT 20;

-- ============================================
-- 8. ADVANCED ANALYTICS QUERIES
-- ============================================

-- Crime hotspots by city
SELECT 
    l.city,
    l.state,
    COUNT(cr.id) as crime_count,
    COUNT(CASE WHEN cc.severity_level = 'critical' THEN 1 END) as critical_crimes
FROM crime_reports cr
INNER JOIN locations l ON cr.location_id = l.id
INNER JOIN crime_categories cc ON cr.category_id = cc.id
WHERE cr.incident_date >= DATE_SUB(CURRENT_DATE, INTERVAL 3 MONTH)
GROUP BY l.city, l.state
HAVING crime_count > 10
ORDER BY crime_count DESC;

-- Officer performance metrics
SELECT 
    u.full_name as officer_name,
    COUNT(cr.id) as total_assigned,
    COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) as resolved_cases,
    ROUND(COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) * 100.0 / COUNT(cr.id), 2) as resolution_rate,
    AVG(CASE 
        WHEN cr.status = 'resolved' AND cr.resolved_date IS NOT NULL 
        THEN TIMESTAMPDIFF(HOUR, cr.reported_date, cr.resolved_date) 
    END) as avg_resolution_hours
FROM users u
LEFT JOIN crime_reports cr ON cr.assigned_officer_id = u.id
WHERE u.role = 'officer'
GROUP BY u.id, u.full_name
ORDER BY resolution_rate DESC;

-- Time-based crime patterns
SELECT 
    HOUR(incident_date) as hour_of_day,
    COUNT(*) as crime_count,
    GROUP_CONCAT(DISTINCT cc.name ORDER BY cc.name) as common_crimes
FROM crime_reports cr
INNER JOIN crime_categories cc ON cr.category_id = cc.id
GROUP BY HOUR(incident_date)
ORDER BY crime_count DESC;

-- ============================================
-- 9. DATA INTEGRITY AND MAINTENANCE
-- ============================================

-- Find reports without evidence
SELECT 
    cr.report_number,
    cr.title,
    cr.status,
    DATEDIFF(CURRENT_DATE, DATE(cr.reported_date)) as days_since_report
FROM crime_reports cr
LEFT JOIN evidence e ON e.crime_report_id = cr.id
WHERE e.id IS NULL
    AND cr.status IN ('investigating', 'pending')
ORDER BY days_since_report DESC;

-- Check for orphaned records
SELECT 
    'Locations without reports' as check_type,
    COUNT(*) as count
FROM locations l
LEFT JOIN crime_reports cr ON cr.location_id = l.id
WHERE cr.id IS NULL

UNION ALL

SELECT 
    'Evidence without reports',
    COUNT(*)
FROM evidence e
LEFT JOIN crime_reports cr ON e.crime_report_id = cr.id
WHERE cr.id IS NULL;

-- ============================================
-- 10. SEARCH AND FILTERING QUERIES
-- ============================================

-- Full-text search across crime reports
SELECT 
    cr.report_number,
    cr.title,
    cr.description,
    cr.status,
    cc.name as category,
    l.city
FROM crime_reports cr
INNER JOIN crime_categories cc ON cr.category_id = cc.id
INNER JOIN locations l ON cr.location_id = l.id
WHERE cr.title LIKE '%theft%' 
    OR cr.description LIKE '%theft%'
ORDER BY cr.reported_date DESC;

-- Advanced filtering with multiple criteria
SELECT 
    cr.report_number,
    cr.title,
    cr.status,
    cr.priority,
    cc.name as category,
    l.city
FROM crime_reports cr
INNER JOIN crime_categories cc ON cr.category_id = cc.id
INNER JOIN locations l ON cr.location_id = l.id
WHERE cr.incident_date BETWEEN '2024-01-01' AND '2024-12-31'
    AND cr.priority IN ('high', 'urgent')
    AND l.city = 'New York'
    AND cr.status != 'closed'
ORDER BY cr.priority DESC, cr.incident_date DESC;
