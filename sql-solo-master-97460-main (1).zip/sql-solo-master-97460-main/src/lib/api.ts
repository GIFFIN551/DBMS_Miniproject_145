// API service for MySQL database interactions
// This would connect to a backend API that communicates with MySQL

export interface CrimeReport {
  id?: number;
  reportNumber?: string;
  userId: number;
  categoryId: number;
  locationId: number;
  title: string;
  description: string;
  status: 'pending' | 'investigating' | 'resolved' | 'closed' | 'rejected';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  incidentDate: string;
  reportedDate?: string;
  isAnonymous: boolean;
  witnessCount?: number;
  evidenceCount?: number;
}

export interface CrimeCategory {
  id: number;
  name: string;
  description: string;
  severityLevel: 'low' | 'medium' | 'high' | 'critical';
  colorCode: string;
  icon: string;
}

export interface Location {
  id?: number;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  latitude?: number;
  longitude?: number;
}

export interface User {
  id: number;
  email: string;
  fullName: string;
  phone?: string;
  role: 'admin' | 'officer' | 'citizen';
}

// Mock API functions - Replace with actual API calls
const API_BASE = '/api'; // Replace with your actual API endpoint

// In-memory storage for submitted reports
let mockReports: CrimeReport[] = [
  {
    id: 1,
    reportNumber: 'CR-2024-001',
    userId: 1,
    categoryId: 1,
    locationId: 1,
    title: 'Theft at Downtown Market',
    description: 'Wallet stolen from bag while shopping',
    status: 'investigating',
    priority: 'medium',
    incidentDate: '2024-01-15T14:30:00',
    reportedDate: '2024-01-15T15:00:00',
    isAnonymous: false,
    witnessCount: 2,
    evidenceCount: 1
  },
  {
    id: 2,
    reportNumber: 'CR-2024-002',
    userId: 2,
    categoryId: 3,
    locationId: 2,
    title: 'Vandalism in City Park',
    description: 'Graffiti on public property',
    status: 'pending',
    priority: 'low',
    incidentDate: '2024-01-16T09:00:00',
    reportedDate: '2024-01-16T10:30:00',
    isAnonymous: true,
    witnessCount: 0,
    evidenceCount: 3
  }
];

// In-memory storage for locations
let mockLocations: Location[] = [
  { id: 1, address: '123 Market St', city: 'Downtown', state: 'CA', country: 'USA', postalCode: '94102', latitude: 37.7749, longitude: -122.4194 },
  { id: 2, address: '456 Park Ave', city: 'San Francisco', state: 'CA', country: 'USA', postalCode: '94103', latitude: 37.7849, longitude: -122.4094 }
];

export const api = {
  // Crime Reports
  async getCrimeReports(): Promise<CrimeReport[]> {
    // Return mock data with submitted reports
    return [...mockReports];
  },

  async createCrimeReport(report: Omit<CrimeReport, 'id' | 'reportNumber'>): Promise<CrimeReport> {
    // In production, this would be: await fetch(`${API_BASE}/reports`, { method: 'POST', body: JSON.stringify(report) })
    const newReport: CrimeReport = {
      ...report,
      id: mockReports.length + 1,
      reportNumber: `CR-2024-${String(mockReports.length + 1).padStart(3, '0')}`,
      reportedDate: new Date().toISOString(),
      witnessCount: 0,
      evidenceCount: 0
    };
    // Add to in-memory storage
    mockReports.push(newReport);
    return newReport;
  },

  async updateCrimeReport(id: number, updates: Partial<CrimeReport>): Promise<CrimeReport> {
    // await fetch(`${API_BASE}/reports/${id}`, { method: 'PUT', body: JSON.stringify(updates) })
    return { id, ...updates } as CrimeReport;
  },

  async deleteCrimeReport(id: number): Promise<void> {
    // await fetch(`${API_BASE}/reports/${id}`, { method: 'DELETE' })
  },

  // Crime Categories
  async getCrimeCategories(): Promise<CrimeCategory[]> {
    return [
      { id: 1, name: 'Theft', description: 'Property theft and burglary', severityLevel: 'medium', colorCode: '#f59e0b', icon: 'package' },
      { id: 2, name: 'Assault', description: 'Physical assault and battery', severityLevel: 'high', colorCode: '#ef4444', icon: 'alert-triangle' },
      { id: 3, name: 'Vandalism', description: 'Property damage and vandalism', severityLevel: 'low', colorCode: '#3b82f6', icon: 'spray-can' },
      { id: 4, name: 'Fraud', description: 'Financial fraud and scams', severityLevel: 'medium', colorCode: '#8b5cf6', icon: 'credit-card' },
      { id: 5, name: 'Drug Related', description: 'Drug possession and trafficking', severityLevel: 'high', colorCode: '#ec4899', icon: 'pill' },
      { id: 6, name: 'Cybercrime', description: 'Online crimes and hacking', severityLevel: 'medium', colorCode: '#06b6d4', icon: 'laptop' },
      { id: 7, name: 'Domestic Violence', description: 'Domestic abuse cases', severityLevel: 'critical', colorCode: '#dc2626', icon: 'home' },
      { id: 8, name: 'Traffic Violation', description: 'Traffic and road violations', severityLevel: 'low', colorCode: '#10b981', icon: 'car' },
      { id: 9, name: 'Robbery', description: 'Armed robbery and mugging', severityLevel: 'critical', colorCode: '#b91c1c', icon: 'shield-alert' },
      { id: 10, name: 'Other', description: 'Other criminal activities', severityLevel: 'medium', colorCode: '#6b7280', icon: 'file-text' }
    ];
  },

  // Locations
  async createLocation(location: Omit<Location, 'id'>): Promise<Location> {
    // await fetch(`${API_BASE}/locations`, { method: 'POST', body: JSON.stringify(location) })
    // Generate random coordinates for demo purposes
    const newLocation: Location = { 
      ...location, 
      id: mockLocations.length + 1,
      latitude: 37.7749 + (Math.random() - 0.5) * 0.1,
      longitude: -122.4194 + (Math.random() - 0.5) * 0.1
    };
    mockLocations.push(newLocation);
    return newLocation;
  },

  async getLocations(): Promise<Location[]> {
    return [...mockLocations];
  },

  // Statistics
  async getStatistics(): Promise<any> {
    return {
      totalReports: 1247,
      pendingReports: 89,
      investigatingReports: 156,
      resolvedReports: 1002,
      averageResolutionTime: 72, // hours
      reportsThisMonth: 234,
      reportsGrowth: 12.5 // percentage
    };
  }
};
