-- ============================================
-- Crime Guard MySQL Stored Procedures
-- ============================================
-- Reusable procedures for common database operations

DELIMITER //

-- ============================================
-- 1. CREATE CRIME REPORT PROCEDURE
-- ============================================
CREATE PROCEDURE sp_create_crime_report(
    IN p_user_id INT,
    IN p_category_id INT,
    IN p_title VARCHAR(255),
    IN p_description TEXT,
    IN p_incident_date DATETIME,
    IN p_address VARCHAR(500),
    IN p_city VARCHAR(100),
    IN p_state VARCHAR(100),
    IN p_priority VARCHAR(20),
    IN p_is_anonymous BOOLEAN,
    OUT p_report_number VARCHAR(50),
    OUT p_report_id INT
)
BEGIN
    DECLARE v_location_id INT;
    DECLARE v_report_count INT;
    
    -- Start transaction
    START TRANSACTION;
    
    -- Create location
    INSERT INTO locations (address, city, state, country)
    VALUES (p_address, p_city, p_state, 'USA');
    
    SET v_location_id = LAST_INSERT_ID();
    
    -- Generate report number
    SELECT COUNT(*) INTO v_report_count FROM crime_reports;
    SET p_report_number = CONCAT('CR-', YEAR(CURRENT_DATE), '-', LPAD(v_report_count + 1, 6, '0'));
    
    -- Create crime report
    INSERT INTO crime_reports (
        report_number, user_id, category_id, location_id,
        title, description, status, priority,
        incident_date, is_anonymous
    )
    VALUES (
        p_report_number, p_user_id, p_category_id, v_location_id,
        p_title, p_description, 'pending', p_priority,
        p_incident_date, p_is_anonymous
    );
    
    SET p_report_id = LAST_INSERT_ID();
    
    -- Create initial update
    INSERT INTO crime_updates (crime_report_id, user_id, update_type, content, is_public)
    VALUES (p_report_id, p_user_id, 'comment', 'Crime report submitted', TRUE);
    
    -- Create notification for admins
    INSERT INTO notifications (user_id, crime_report_id, title, message, notification_type)
    SELECT id, p_report_id, 'New Crime Report', 
           CONCAT('New report ', p_report_number, ' has been submitted'), 'info'
    FROM users WHERE role = 'admin';
    
    COMMIT;
END //

-- ============================================
-- 2. ASSIGN OFFICER TO REPORT
-- ============================================
CREATE PROCEDURE sp_assign_officer_to_report(
    IN p_report_id INT,
    IN p_officer_id INT,
    IN p_assigned_by INT
)
BEGIN
    DECLARE v_report_number VARCHAR(50);
    DECLARE v_user_id INT;
    
    START TRANSACTION;
    
    -- Get report details
    SELECT report_number, user_id INTO v_report_number, v_user_id
    FROM crime_reports WHERE id = p_report_id;
    
    -- Update report
    UPDATE crime_reports
    SET assigned_officer_id = p_officer_id,
        status = 'investigating',
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_report_id;
    
    -- Add update log
    INSERT INTO crime_updates (crime_report_id, user_id, update_type, content, is_public)
    VALUES (p_report_id, p_assigned_by, 'assignment',
            CONCAT('Case assigned to officer ID: ', p_officer_id), TRUE);
    
    -- Notify officer
    INSERT INTO notifications (user_id, crime_report_id, title, message, notification_type)
    VALUES (p_officer_id, p_report_id, 'New Case Assignment',
            CONCAT('You have been assigned to case ', v_report_number), 'info');
    
    -- Notify reporter
    IF v_user_id IS NOT NULL THEN
        INSERT INTO notifications (user_id, crime_report_id, title, message, notification_type)
        VALUES (v_user_id, p_report_id, 'Case Update',
                CONCAT('Your report ', v_report_number, ' is now being investigated'), 'success');
    END IF;
    
    COMMIT;
END //

-- ============================================
-- 3. RESOLVE CRIME REPORT
-- ============================================
CREATE PROCEDURE sp_resolve_crime_report(
    IN p_report_id INT,
    IN p_resolved_by INT,
    IN p_resolution_notes TEXT
)
BEGIN
    DECLARE v_report_number VARCHAR(50);
    DECLARE v_user_id INT;
    
    START TRANSACTION;
    
    -- Get report details
    SELECT report_number, user_id INTO v_report_number, v_user_id
    FROM crime_reports WHERE id = p_report_id;
    
    -- Update report status
    UPDATE crime_reports
    SET status = 'resolved',
        resolved_date = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_report_id;
    
    -- Add resolution update
    INSERT INTO crime_updates (crime_report_id, user_id, update_type, content, is_public)
    VALUES (p_report_id, p_resolved_by, 'status_change', p_resolution_notes, TRUE);
    
    -- Notify reporter
    IF v_user_id IS NOT NULL THEN
        INSERT INTO notifications (user_id, crime_report_id, title, message, notification_type)
        VALUES (v_user_id, p_report_id, 'Case Resolved',
                CONCAT('Your report ', v_report_number, ' has been resolved'), 'success');
    END IF;
    
    COMMIT;
END //

-- ============================================
-- 4. ADD EVIDENCE TO REPORT
-- ============================================
CREATE PROCEDURE sp_add_evidence(
    IN p_report_id INT,
    IN p_evidence_type VARCHAR(20),
    IN p_file_name VARCHAR(255),
    IN p_file_path VARCHAR(500),
    IN p_file_size INT,
    IN p_description TEXT,
    IN p_uploaded_by INT
)
BEGIN
    START TRANSACTION;
    
    -- Insert evidence
    INSERT INTO evidence (
        crime_report_id, evidence_type, file_name, 
        file_path, file_size, description, uploaded_by
    )
    VALUES (
        p_report_id, p_evidence_type, p_file_name,
        p_file_path, p_file_size, p_description, p_uploaded_by
    );
    
    -- Update evidence count
    UPDATE crime_reports
    SET evidence_count = evidence_count + 1,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_report_id;
    
    -- Add update log
    INSERT INTO crime_updates (crime_report_id, user_id, update_type, content, is_public)
    VALUES (p_report_id, p_uploaded_by, 'evidence_added',
            CONCAT('New evidence added: ', p_file_name), TRUE);
    
    COMMIT;
END //

-- ============================================
-- 5. GET CRIME STATISTICS
-- ============================================
CREATE PROCEDURE sp_get_crime_statistics(
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_city VARCHAR(100)
)
BEGIN
    SELECT 
        DATE(cr.incident_date) as report_date,
        l.city,
        cc.name as category,
        COUNT(*) as total_reports,
        COUNT(CASE WHEN cr.status = 'pending' THEN 1 END) as pending,
        COUNT(CASE WHEN cr.status = 'investigating' THEN 1 END) as investigating,
        COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) as resolved,
        AVG(CASE 
            WHEN cr.status = 'resolved' AND cr.resolved_date IS NOT NULL 
            THEN TIMESTAMPDIFF(HOUR, cr.reported_date, cr.resolved_date)
        END) as avg_resolution_hours
    FROM crime_reports cr
    INNER JOIN locations l ON cr.location_id = l.id
    INNER JOIN crime_categories cc ON cr.category_id = cc.id
    WHERE cr.incident_date BETWEEN p_start_date AND p_end_date
        AND (p_city IS NULL OR l.city = p_city)
    GROUP BY DATE(cr.incident_date), l.city, cc.name
    ORDER BY report_date DESC, total_reports DESC;
END //

-- ============================================
-- 6. UPDATE DAILY STATISTICS
-- ============================================
CREATE PROCEDURE sp_update_daily_statistics(
    IN p_date DATE
)
BEGIN
    -- Insert or update daily statistics
    INSERT INTO crime_statistics (
        date, category_id, city, total_reports, 
        pending_reports, resolved_reports, average_resolution_time_hours
    )
    SELECT 
        p_date,
        cr.category_id,
        l.city,
        COUNT(*) as total_reports,
        COUNT(CASE WHEN cr.status = 'pending' THEN 1 END) as pending,
        COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) as resolved,
        AVG(CASE 
            WHEN cr.status = 'resolved' AND cr.resolved_date IS NOT NULL 
            THEN TIMESTAMPDIFF(HOUR, cr.reported_date, cr.resolved_date)
        END) as avg_hours
    FROM crime_reports cr
    INNER JOIN locations l ON cr.location_id = l.id
    WHERE DATE(cr.incident_date) = p_date
    GROUP BY cr.category_id, l.city
    ON DUPLICATE KEY UPDATE
        total_reports = VALUES(total_reports),
        pending_reports = VALUES(pending_reports),
        resolved_reports = VALUES(resolved_reports),
        average_resolution_time_hours = VALUES(average_resolution_time_hours),
        updated_at = CURRENT_TIMESTAMP;
END //

-- ============================================
-- 7. CLEANUP OLD NOTIFICATIONS
-- ============================================
CREATE PROCEDURE sp_cleanup_old_notifications(
    IN p_days_old INT
)
BEGIN
    DELETE FROM notifications
    WHERE is_read = TRUE
        AND created_at < DATE_SUB(CURRENT_DATE, INTERVAL p_days_old DAY);
    
    SELECT ROW_COUNT() as deleted_count;
END //

-- ============================================
-- 8. GET OFFICER WORKLOAD
-- ============================================
CREATE PROCEDURE sp_get_officer_workload()
BEGIN
    SELECT 
        u.id,
        u.full_name,
        u.email,
        COUNT(cr.id) as active_cases,
        COUNT(CASE WHEN cr.priority = 'urgent' THEN 1 END) as urgent_cases,
        COUNT(CASE WHEN cr.priority = 'high' THEN 1 END) as high_priority_cases,
        AVG(DATEDIFF(CURRENT_DATE, DATE(cr.reported_date))) as avg_case_age_days
    FROM users u
    LEFT JOIN crime_reports cr ON cr.assigned_officer_id = u.id 
        AND cr.status IN ('investigating', 'pending')
    WHERE u.role = 'officer' AND u.is_verified = TRUE
    GROUP BY u.id, u.full_name, u.email
    ORDER BY active_cases ASC;
END //

-- ============================================
-- 9. BULK ASSIGN REPORTS
-- ============================================
CREATE PROCEDURE sp_bulk_assign_reports(
    IN p_category_id INT,
    IN p_city VARCHAR(100),
    IN p_officer_id INT
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_report_id INT;
    DECLARE cur CURSOR FOR 
        SELECT cr.id
        FROM crime_reports cr
        INNER JOIN locations l ON cr.location_id = l.id
        WHERE cr.category_id = p_category_id
            AND l.city = p_city
            AND cr.status = 'pending'
            AND cr.assigned_officer_id IS NULL;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    START TRANSACTION;
    
    OPEN cur;
    
    read_loop: LOOP
        FETCH cur INTO v_report_id;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        UPDATE crime_reports
        SET assigned_officer_id = p_officer_id,
            status = 'investigating',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = v_report_id;
        
        INSERT INTO crime_updates (crime_report_id, user_id, update_type, content)
        VALUES (v_report_id, p_officer_id, 'assignment', 
                'Auto-assigned based on category and location');
    END LOOP;
    
    CLOSE cur;
    COMMIT;
    
    SELECT ROW_COUNT() as assigned_count;
END //

-- ============================================
-- 10. ARCHIVE OLD REPORTS
-- ============================================
CREATE PROCEDURE sp_archive_old_reports(
    IN p_days_old INT
)
BEGIN
    START TRANSACTION;
    
    -- Update old resolved reports to closed
    UPDATE crime_reports
    SET status = 'closed',
        updated_at = CURRENT_TIMESTAMP
    WHERE status = 'resolved'
        AND resolved_date < DATE_SUB(CURRENT_DATE, INTERVAL p_days_old DAY);
    
    SELECT ROW_COUNT() as archived_count;
    
    COMMIT;
END //

DELIMITER ;

-- ============================================
-- EXAMPLE PROCEDURE CALLS
-- ============================================

-- Create a new crime report
/*
CALL sp_create_crime_report(
    1, 1, 'Bicycle Theft', 'My bicycle was stolen from the parking lot',
    '2024-01-15 14:30:00', '123 Main St', 'New York', 'NY',
    'medium', FALSE, @report_num, @report_id
);
SELECT @report_num, @report_id;
*/

-- Assign officer to report
/*
CALL sp_assign_officer_to_report(1, 5, 1);
*/

-- Resolve a report
/*
CALL sp_resolve_crime_report(
    1, 5, 'Suspect identified and arrested. Bicycle recovered.'
);
*/

-- Get statistics
/*
CALL sp_get_crime_statistics('2024-01-01', '2024-12-31', 'New York');
*/

-- Get officer workload
/*
CALL sp_get_officer_workload();
*/
