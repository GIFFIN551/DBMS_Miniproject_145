-- ============================================
-- Crime Guard MySQL Indexes and Optimization
-- ============================================
-- Performance optimization through strategic indexing

-- ============================================
-- 1. PRIMARY TABLES INDEXES
-- ============================================

-- Users table indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_verified ON users(is_verified);
CREATE INDEX idx_users_role_verified ON users(role, is_verified);
CREATE INDEX idx_users_last_login ON users(last_login);

-- Crime reports indexes
CREATE INDEX idx_reports_status ON crime_reports(status);
CREATE INDEX idx_reports_priority ON crime_reports(priority);
CREATE INDEX idx_reports_user_id ON crime_reports(user_id);
CREATE INDEX idx_reports_category_id ON crime_reports(category_id);
CREATE INDEX idx_reports_location_id ON crime_reports(location_id);
CREATE INDEX idx_reports_officer_id ON crime_reports(assigned_officer_id);
CREATE INDEX idx_reports_incident_date ON crime_reports(incident_date);
CREATE INDEX idx_reports_reported_date ON crime_reports(reported_date);
CREATE INDEX idx_reports_report_number ON crime_reports(report_number);

-- Composite indexes for common query patterns
CREATE INDEX idx_reports_status_priority ON crime_reports(status, priority);
CREATE INDEX idx_reports_status_date ON crime_reports(status, incident_date);
CREATE INDEX idx_reports_officer_status ON crime_reports(assigned_officer_id, status);
CREATE INDEX idx_reports_category_status ON crime_reports(category_id, status);

-- Locations table indexes
CREATE INDEX idx_locations_city ON locations(city);
CREATE INDEX idx_locations_state ON locations(state);
CREATE INDEX idx_locations_city_state ON locations(city, state);
CREATE INDEX idx_locations_coordinates ON locations(latitude, longitude);
CREATE INDEX idx_locations_postal_code ON locations(postal_code);

-- Crime categories indexes
CREATE INDEX idx_categories_name ON crime_categories(name);
CREATE INDEX idx_categories_severity ON crime_categories(severity_level);
CREATE INDEX idx_categories_active ON crime_categories(is_active);

-- ============================================
-- 2. EVIDENCE AND WITNESS INDEXES
-- ============================================

-- Evidence table indexes
CREATE INDEX idx_evidence_report_id ON evidence(crime_report_id);
CREATE INDEX idx_evidence_type ON evidence(evidence_type);
CREATE INDEX idx_evidence_uploaded_by ON evidence(uploaded_by);
CREATE INDEX idx_evidence_uploaded_at ON evidence(uploaded_at);
CREATE INDEX idx_evidence_report_type ON evidence(crime_report_id, evidence_type);

-- Witnesses table indexes
CREATE INDEX idx_witnesses_report_id ON witnesses(crime_report_id);
CREATE INDEX idx_witnesses_contacted ON witnesses(contacted);
CREATE INDEX idx_witnesses_anonymous ON witnesses(is_anonymous);
CREATE INDEX idx_witnesses_created_at ON witnesses(created_at);

-- ============================================
-- 3. UPDATES AND NOTIFICATIONS INDEXES
-- ============================================

-- Crime updates indexes
CREATE INDEX idx_updates_report_id ON crime_updates(crime_report_id);
CREATE INDEX idx_updates_user_id ON crime_updates(user_id);
CREATE INDEX idx_updates_type ON crime_updates(update_type);
CREATE INDEX idx_updates_created_at ON crime_updates(created_at);
CREATE INDEX idx_updates_public ON crime_updates(is_public);
CREATE INDEX idx_updates_report_date ON crime_updates(crime_report_id, created_at);

-- Notifications indexes
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_read ON notifications(is_read);
CREATE INDEX idx_notifications_type ON notifications(notification_type);
CREATE INDEX idx_notifications_created_at ON notifications(created_at);
CREATE INDEX idx_notifications_report_id ON notifications(crime_report_id);
CREATE INDEX idx_notifications_user_read ON notifications(user_id, is_read);
CREATE INDEX idx_notifications_user_date ON notifications(user_id, created_at);

-- ============================================
-- 4. STATISTICS TABLE INDEXES
-- ============================================

-- Crime statistics indexes
CREATE INDEX idx_stats_date ON crime_statistics(date);
CREATE INDEX idx_stats_city ON crime_statistics(city);
CREATE INDEX idx_stats_category_id ON crime_statistics(category_id);
CREATE INDEX idx_stats_date_city ON crime_statistics(date, city);
CREATE INDEX idx_stats_date_category ON crime_statistics(date, category_id);
CREATE UNIQUE INDEX idx_stats_unique ON crime_statistics(date, category_id, city);

-- ============================================
-- 5. FULL-TEXT SEARCH INDEXES
-- ============================================

-- Full-text search on crime reports
CREATE FULLTEXT INDEX idx_ft_reports_title ON crime_reports(title);
CREATE FULLTEXT INDEX idx_ft_reports_description ON crime_reports(description);
CREATE FULLTEXT INDEX idx_ft_reports_title_desc ON crime_reports(title, description);

-- Full-text search on locations
CREATE FULLTEXT INDEX idx_ft_locations_address ON locations(address);

-- Full-text search on crime updates
CREATE FULLTEXT INDEX idx_ft_updates_content ON crime_updates(content);

-- ============================================
-- 6. COVERING INDEXES FOR COMMON QUERIES
-- ============================================

-- Covering index for dashboard queries
CREATE INDEX idx_reports_dashboard ON crime_reports(
    status, priority, incident_date, category_id, location_id
);

-- Covering index for officer workload queries
CREATE INDEX idx_reports_officer_work ON crime_reports(
    assigned_officer_id, status, priority, reported_date
);

-- Covering index for statistics queries
CREATE INDEX idx_reports_stats ON crime_reports(
    incident_date, category_id, status, reported_date, resolved_date
);

-- ============================================
-- 7. ANALYZE TABLES FOR OPTIMIZATION
-- ============================================

ANALYZE TABLE users;
ANALYZE TABLE crime_reports;
ANALYZE TABLE crime_categories;
ANALYZE TABLE locations;
ANALYZE TABLE evidence;
ANALYZE TABLE witnesses;
ANALYZE TABLE crime_updates;
ANALYZE TABLE notifications;
ANALYZE TABLE crime_statistics;

-- ============================================
-- 8. INDEX USAGE ANALYSIS QUERIES
-- ============================================

-- Check index statistics
/*
SELECT 
    TABLE_NAME,
    INDEX_NAME,
    SEQ_IN_INDEX,
    COLUMN_NAME,
    CARDINALITY,
    INDEX_TYPE
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = 'crime_guard_db'
ORDER BY TABLE_NAME, INDEX_NAME, SEQ_IN_INDEX;
*/

-- Show unused indexes
/*
SELECT 
    t.TABLE_SCHEMA,
    t.TABLE_NAME,
    s.INDEX_NAME
FROM information_schema.TABLES t
INNER JOIN information_schema.STATISTICS s 
    ON t.TABLE_SCHEMA = s.TABLE_SCHEMA 
    AND t.TABLE_NAME = s.TABLE_NAME
LEFT JOIN performance_schema.table_io_waits_summary_by_index_usage i
    ON i.OBJECT_SCHEMA = s.TABLE_SCHEMA
    AND i.OBJECT_NAME = s.TABLE_NAME
    AND i.INDEX_NAME = s.INDEX_NAME
WHERE t.TABLE_SCHEMA = 'crime_guard_db'
    AND s.INDEX_NAME != 'PRIMARY'
    AND (i.INDEX_NAME IS NULL OR i.COUNT_STAR = 0)
GROUP BY t.TABLE_SCHEMA, t.TABLE_NAME, s.INDEX_NAME;
*/

-- ============================================
-- 9. PERFORMANCE OPTIMIZATION QUERIES
-- ============================================

-- Get table sizes and index sizes
/*
SELECT 
    TABLE_NAME,
    ROUND(((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024), 2) AS 'Size (MB)',
    ROUND((DATA_LENGTH / 1024 / 1024), 2) AS 'Data Size (MB)',
    ROUND((INDEX_LENGTH / 1024 / 1024), 2) AS 'Index Size (MB)',
    TABLE_ROWS AS 'Row Count'
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'crime_guard_db'
ORDER BY (DATA_LENGTH + INDEX_LENGTH) DESC;
*/

-- Check slow queries
/*
SELECT 
    query_time,
    lock_time,
    rows_sent,
    rows_examined,
    sql_text
FROM mysql.slow_log
WHERE start_time >= DATE_SUB(NOW(), INTERVAL 1 DAY)
ORDER BY query_time DESC
LIMIT 20;
*/

-- ============================================
-- 10. INDEX MAINTENANCE COMMANDS
-- ============================================

-- Optimize tables (reorganize data and indexes)
/*
OPTIMIZE TABLE users;
OPTIMIZE TABLE crime_reports;
OPTIMIZE TABLE locations;
OPTIMIZE TABLE evidence;
OPTIMIZE TABLE witnesses;
OPTIMIZE TABLE crime_updates;
OPTIMIZE TABLE notifications;
OPTIMIZE TABLE crime_statistics;
*/

-- Check table integrity
/*
CHECK TABLE crime_reports;
CHECK TABLE users;
CHECK TABLE locations;
*/

-- Repair table if needed
/*
REPAIR TABLE crime_reports;
*/

-- ============================================
-- 11. QUERY PERFORMANCE TESTING
-- ============================================

-- Example: Test query performance with EXPLAIN
/*
EXPLAIN SELECT 
    cr.report_number,
    cr.title,
    cr.status,
    u.full_name,
    cc.name as category,
    l.city
FROM crime_reports cr
INNER JOIN users u ON cr.user_id = u.id
INNER JOIN crime_categories cc ON cr.category_id = cc.id
INNER JOIN locations l ON cr.location_id = l.id
WHERE cr.status = 'pending'
    AND cr.priority IN ('high', 'urgent')
ORDER BY cr.incident_date DESC;
*/

-- Analyze query execution
/*
EXPLAIN ANALYZE SELECT 
    cr.report_number,
    COUNT(e.id) as evidence_count
FROM crime_reports cr
LEFT JOIN evidence e ON e.crime_report_id = cr.id
WHERE cr.incident_date >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
GROUP BY cr.id, cr.report_number;
*/

-- ============================================
-- 12. DROP UNUSED INDEXES (if needed)
-- ============================================
/*
-- Example of dropping an index if it's not being used
DROP INDEX idx_locations_postal_code ON locations;
DROP INDEX idx_evidence_uploaded_at ON evidence;
*/

-- ============================================
-- BEST PRACTICES NOTES
-- ============================================
/*
1. Indexes speed up SELECT queries but slow down INSERT/UPDATE/DELETE
2. Don't index every column - focus on:
   - Foreign keys
   - Columns in WHERE clauses
   - Columns in ORDER BY clauses
   - Columns in JOIN conditions
3. Composite indexes should have most selective column first
4. Monitor index usage regularly
5. Rebuild indexes periodically for large tables
6. Use EXPLAIN to analyze query execution plans
7. Consider covering indexes for frequently used queries
8. Full-text indexes for text search operations
9. Keep statistics up to date with ANALYZE TABLE
10. Remove unused indexes to improve write performance
*/
