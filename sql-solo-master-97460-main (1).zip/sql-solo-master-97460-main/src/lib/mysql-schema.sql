-- Crime Guard MySQL Database Schema
-- This schema is designed for a comprehensive crime reporting and tracking system

-- Users table for authentication and user management
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    role ENUM('admin', 'officer', 'citizen') DEFAULT 'citizen',
    is_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    INDEX idx_email (email),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Crime categories table
CREATE TABLE IF NOT EXISTS crime_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    severity_level ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    color_code VARCHAR(7) DEFAULT '#3b82f6',
    icon VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Locations table for crime locations
CREATE TABLE IF NOT EXISTS locations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    address VARCHAR(500) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'USA',
    postal_code VARCHAR(20),
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_city (city),
    INDEX idx_coordinates (latitude, longitude)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Crime reports table
CREATE TABLE IF NOT EXISTS crime_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_number VARCHAR(50) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    category_id INT NOT NULL,
    location_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    status ENUM('pending', 'investigating', 'resolved', 'closed', 'rejected') DEFAULT 'pending',
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    incident_date DATETIME NOT NULL,
    reported_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_date TIMESTAMP NULL,
    is_anonymous BOOLEAN DEFAULT FALSE,
    witness_count INT DEFAULT 0,
    evidence_count INT DEFAULT 0,
    assigned_officer_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES crime_categories(id),
    FOREIGN KEY (location_id) REFERENCES locations(id),
    FOREIGN KEY (assigned_officer_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_report_number (report_number),
    INDEX idx_status (status),
    INDEX idx_priority (priority),
    INDEX idx_incident_date (incident_date),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Evidence table for crime evidence
CREATE TABLE IF NOT EXISTS evidence (
    id INT AUTO_INCREMENT PRIMARY KEY,
    crime_report_id INT NOT NULL,
    evidence_type ENUM('photo', 'video', 'document', 'audio', 'other') NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT,
    description TEXT,
    uploaded_by INT NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (crime_report_id) REFERENCES crime_reports(id) ON DELETE CASCADE,
    FOREIGN KEY (uploaded_by) REFERENCES users(id),
    INDEX idx_crime_report (crime_report_id),
    INDEX idx_evidence_type (evidence_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Witnesses table
CREATE TABLE IF NOT EXISTS witnesses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    crime_report_id INT NOT NULL,
    full_name VARCHAR(255),
    phone VARCHAR(20),
    email VARCHAR(255),
    statement TEXT,
    is_anonymous BOOLEAN DEFAULT FALSE,
    contacted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (crime_report_id) REFERENCES crime_reports(id) ON DELETE CASCADE,
    INDEX idx_crime_report (crime_report_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Comments/Updates table for crime reports
CREATE TABLE IF NOT EXISTS crime_updates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    crime_report_id INT NOT NULL,
    user_id INT NOT NULL,
    update_type ENUM('comment', 'status_change', 'assignment', 'evidence_added') NOT NULL,
    content TEXT NOT NULL,
    is_public BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (crime_report_id) REFERENCES crime_reports(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_crime_report (crime_report_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    crime_report_id INT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    notification_type ENUM('info', 'warning', 'success', 'error') DEFAULT 'info',
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (crime_report_id) REFERENCES crime_reports(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Statistics table for analytics
CREATE TABLE IF NOT EXISTS crime_statistics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date DATE NOT NULL,
    category_id INT NOT NULL,
    city VARCHAR(100) NOT NULL,
    total_reports INT DEFAULT 0,
    pending_reports INT DEFAULT 0,
    resolved_reports INT DEFAULT 0,
    average_resolution_time_hours DECIMAL(10, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES crime_categories(id),
    UNIQUE KEY unique_daily_stat (date, category_id, city),
    INDEX idx_date (date),
    INDEX idx_city (city)
) ENGINE=InnoDB DEFAULT CHARSET=ut8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default crime categories
INSERT INTO crime_categories (name, description, severity_level, color_code, icon) VALUES
('Theft', 'Property theft and burglary', 'medium', '#f59e0b', 'package'),
('Assault', 'Physical assault and battery', 'high', '#ef4444', 'alert-triangle'),
('Vandalism', 'Property damage and vandalism', 'low', '#3b82f6', 'spray-can'),
('Fraud', 'Financial fraud and scams', 'medium', '#8b5cf6', 'credit-card'),
('Drug Related', 'Drug possession and trafficking', 'high', '#ec4899', 'pill'),
('Cybercrime', 'Online crimes and hacking', 'medium', '#06b6d4', 'laptop'),
('Domestic Violence', 'Domestic abuse cases', 'critical', '#dc2626', 'home'),
('Traffic Violation', 'Traffic and road violations', 'low', '#10b981', 'car'),
('Robbery', 'Armed robbery and mugging', 'critical', '#b91c1c', 'shield-alert'),
('Other', 'Other criminal activities', 'medium', '#6b7280', 'file-text');
