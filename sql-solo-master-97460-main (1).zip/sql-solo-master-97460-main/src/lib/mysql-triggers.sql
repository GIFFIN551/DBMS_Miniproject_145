-- ============================================
-- Crime Guard MySQL Triggers
-- ============================================
-- Automated actions triggered by database events

DELIMITER //

-- ============================================
-- 1. AUTO-UPDATE REPORT TIMESTAMPS
-- ============================================

-- Trigger to update timestamp when report is modified
CREATE TRIGGER trg_update_report_timestamp
BEFORE UPDATE ON crime_reports
FOR EACH ROW
BEGIN
    SET NEW.updated_at = CURRENT_TIMESTAMP;
END //

-- ============================================
-- 2. AUTO-INCREMENT EVIDENCE COUNT
-- ============================================

-- Trigger when evidence is added
CREATE TRIGGER trg_increment_evidence_count
AFTER INSERT ON evidence
FOR EACH ROW
BEGIN
    UPDATE crime_reports
    SET evidence_count = evidence_count + 1
    WHERE id = NEW.crime_report_id;
END //

-- Trigger when evidence is deleted
CREATE TRIGGER trg_decrement_evidence_count
AFTER DELETE ON evidence
FOR EACH ROW
BEGIN
    UPDATE crime_reports
    SET evidence_count = GREATEST(evidence_count - 1, 0)
    WHERE id = OLD.crime_report_id;
END //

-- ============================================
-- 3. AUTO-INCREMENT WITNESS COUNT
-- ============================================

-- Trigger when witness is added
CREATE TRIGGER trg_increment_witness_count
AFTER INSERT ON witnesses
FOR EACH ROW
BEGIN
    UPDATE crime_reports
    SET witness_count = witness_count + 1
    WHERE id = NEW.crime_report_id;
END //

-- Trigger when witness is deleted
CREATE TRIGGER trg_decrement_witness_count
AFTER DELETE ON witnesses
FOR EACH ROW
BEGIN
    UPDATE crime_reports
    SET witness_count = GREATEST(witness_count - 1, 0)
    WHERE id = OLD.crime_report_id;
END //

-- ============================================
-- 4. STATUS CHANGE NOTIFICATION
-- ============================================

-- Trigger to notify when report status changes
CREATE TRIGGER trg_notify_status_change
AFTER UPDATE ON crime_reports
FOR EACH ROW
BEGIN
    IF OLD.status != NEW.status THEN
        -- Notify the reporter
        IF NEW.user_id IS NOT NULL THEN
            INSERT INTO notifications (
                user_id, crime_report_id, title, message, notification_type
            )
            VALUES (
                NEW.user_id,
                NEW.id,
                'Report Status Updated',
                CONCAT('Your report ', NEW.report_number, ' status changed from ',
                       OLD.status, ' to ', NEW.status),
                CASE 
                    WHEN NEW.status = 'resolved' THEN 'success'
                    WHEN NEW.status = 'investigating' THEN 'info'
                    WHEN NEW.status = 'rejected' THEN 'error'
                    ELSE 'info'
                END
            );
        END IF;
        
        -- Notify assigned officer if exists
        IF NEW.assigned_officer_id IS NOT NULL AND NEW.assigned_officer_id != OLD.assigned_officer_id THEN
            INSERT INTO notifications (
                user_id, crime_report_id, title, message, notification_type
            )
            VALUES (
                NEW.assigned_officer_id,
                NEW.id,
                'Case Status Changed',
                CONCAT('Case ', NEW.report_number, ' status is now ', NEW.status),
                'info'
            );
        END IF;
    END IF;
END //

-- ============================================
-- 5. AUTO-LOG STATUS CHANGES
-- ============================================

-- Automatically log status changes to crime_updates
CREATE TRIGGER trg_log_status_change
AFTER UPDATE ON crime_reports
FOR EACH ROW
BEGIN
    IF OLD.status != NEW.status THEN
        INSERT INTO crime_updates (
            crime_report_id, user_id, update_type, content, is_public
        )
        VALUES (
            NEW.id,
            COALESCE(NEW.assigned_officer_id, NEW.user_id),
            'status_change',
            CONCAT('Status changed from ', OLD.status, ' to ', NEW.status),
            TRUE
        );
    END IF;
END //

-- ============================================
-- 6. AUTO-LOG PRIORITY CHANGES
-- ============================================

-- Log when priority is escalated
CREATE TRIGGER trg_log_priority_change
AFTER UPDATE ON crime_reports
FOR EACH ROW
BEGIN
    IF OLD.priority != NEW.priority THEN
        INSERT INTO crime_updates (
            crime_report_id, user_id, update_type, content, is_public
        )
        VALUES (
            NEW.id,
            COALESCE(NEW.assigned_officer_id, NEW.user_id),
            'status_change',
            CONCAT('Priority changed from ', OLD.priority, ' to ', NEW.priority),
            TRUE
        );
        
        -- Send notification if priority increased to urgent or high
        IF NEW.priority IN ('urgent', 'high') AND OLD.priority NOT IN ('urgent', 'high') THEN
            -- Notify all admins
            INSERT INTO notifications (
                user_id, crime_report_id, title, message, notification_type
            )
            SELECT 
                id,
                NEW.id,
                'High Priority Alert',
                CONCAT('Report ', NEW.report_number, ' priority escalated to ', NEW.priority),
                'warning'
            FROM users
            WHERE role = 'admin';
        END IF;
    END IF;
END //

-- ============================================
-- 7. PREVENT DELETION OF ACTIVE REPORTS
-- ============================================

-- Prevent deletion of reports that are not closed
CREATE TRIGGER trg_prevent_active_report_deletion
BEFORE DELETE ON crime_reports
FOR EACH ROW
BEGIN
    IF OLD.status NOT IN ('closed', 'rejected') THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot delete active crime reports. Close or reject the report first.';
    END IF;
END //

-- ============================================
-- 8. VALIDATE REPORT ASSIGNMENT
-- ============================================

-- Ensure only officers can be assigned to reports
CREATE TRIGGER trg_validate_officer_assignment
BEFORE UPDATE ON crime_reports
FOR EACH ROW
BEGIN
    DECLARE v_role VARCHAR(20);
    
    IF NEW.assigned_officer_id IS NOT NULL AND 
       (OLD.assigned_officer_id IS NULL OR NEW.assigned_officer_id != OLD.assigned_officer_id) THEN
        
        SELECT role INTO v_role
        FROM users
        WHERE id = NEW.assigned_officer_id;
        
        IF v_role != 'officer' THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Only users with officer role can be assigned to reports';
        END IF;
    END IF;
END //

-- ============================================
-- 9. AUTO-UPDATE STATISTICS ON RESOLUTION
-- ============================================

-- Update daily statistics when report is resolved
CREATE TRIGGER trg_update_stats_on_resolution
AFTER UPDATE ON crime_reports
FOR EACH ROW
BEGIN
    IF OLD.status != 'resolved' AND NEW.status = 'resolved' THEN
        -- Update or insert daily statistics
        INSERT INTO crime_statistics (
            date, category_id, city, total_reports, 
            pending_reports, resolved_reports, average_resolution_time_hours
        )
        SELECT 
            CURRENT_DATE,
            NEW.category_id,
            l.city,
            1,
            0,
            1,
            TIMESTAMPDIFF(HOUR, NEW.reported_date, NEW.resolved_date)
        FROM locations l
        WHERE l.id = NEW.location_id
        ON DUPLICATE KEY UPDATE
            resolved_reports = resolved_reports + 1,
            average_resolution_time_hours = (
                (average_resolution_time_hours * resolved_reports + 
                 TIMESTAMPDIFF(HOUR, NEW.reported_date, NEW.resolved_date)) / 
                (resolved_reports + 1)
            );
    END IF;
END //

-- ============================================
-- 10. AUDIT LOG FOR USER CHANGES
-- ============================================

-- Create audit table if not exists
CREATE TABLE IF NOT EXISTS audit_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(50) NOT NULL,
    record_id INT NOT NULL,
    action VARCHAR(20) NOT NULL,
    old_value TEXT,
    new_value TEXT,
    changed_by INT,
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_table_record (table_name, record_id),
    INDEX idx_changed_at (changed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci //

-- Audit trigger for crime_reports
CREATE TRIGGER trg_audit_crime_reports_update
AFTER UPDATE ON crime_reports
FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, record_id, action, old_value, new_value, changed_by)
    VALUES (
        'crime_reports',
        NEW.id,
        'UPDATE',
        JSON_OBJECT(
            'status', OLD.status,
            'priority', OLD.priority,
            'assigned_officer_id', OLD.assigned_officer_id
        ),
        JSON_OBJECT(
            'status', NEW.status,
            'priority', NEW.priority,
            'assigned_officer_id', NEW.assigned_officer_id
        ),
        NEW.assigned_officer_id
    );
END //

-- ============================================
-- 11. VALIDATE EVIDENCE FILE SIZE
-- ============================================

-- Prevent uploading evidence files larger than 100MB
CREATE TRIGGER trg_validate_evidence_size
BEFORE INSERT ON evidence
FOR EACH ROW
BEGIN
    IF NEW.file_size > 104857600 THEN  -- 100MB in bytes
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Evidence file size cannot exceed 100MB';
    END IF;
END //

-- ============================================
-- 12. AUTO-SET RESOLVED DATE
-- ============================================

-- Automatically set resolved_date when status changes to resolved
CREATE TRIGGER trg_set_resolved_date
BEFORE UPDATE ON crime_reports
FOR EACH ROW
BEGIN
    IF OLD.status != 'resolved' AND NEW.status = 'resolved' THEN
        SET NEW.resolved_date = CURRENT_TIMESTAMP;
    END IF;
    
    -- Clear resolved_date if status changes from resolved
    IF OLD.status = 'resolved' AND NEW.status != 'resolved' THEN
        SET NEW.resolved_date = NULL;
    END IF;
END //

DELIMITER ;

-- ============================================
-- DISPLAY ALL TRIGGERS
-- ============================================
/*
SHOW TRIGGERS FROM crime_guard_db;

-- Or get detailed trigger information:
SELECT 
    TRIGGER_NAME,
    EVENT_MANIPULATION,
    EVENT_OBJECT_TABLE,
    ACTION_TIMING,
    ACTION_STATEMENT
FROM information_schema.TRIGGERS
WHERE TRIGGER_SCHEMA = 'crime_guard_db'
ORDER BY EVENT_OBJECT_TABLE, ACTION_TIMING;
*/

-- ============================================
-- DROP TRIGGERS (if needed for updates)
-- ============================================
/*
DROP TRIGGER IF EXISTS trg_update_report_timestamp;
DROP TRIGGER IF EXISTS trg_increment_evidence_count;
DROP TRIGGER IF EXISTS trg_decrement_evidence_count;
DROP TRIGGER IF EXISTS trg_increment_witness_count;
DROP TRIGGER IF EXISTS trg_decrement_witness_count;
DROP TRIGGER IF EXISTS trg_notify_status_change;
DROP TRIGGER IF EXISTS trg_log_status_change;
DROP TRIGGER IF EXISTS trg_log_priority_change;
DROP TRIGGER IF EXISTS trg_prevent_active_report_deletion;
DROP TRIGGER IF EXISTS trg_validate_officer_assignment;
DROP TRIGGER IF EXISTS trg_update_stats_on_resolution;
DROP TRIGGER IF EXISTS trg_audit_crime_reports_update;
DROP TRIGGER IF EXISTS trg_validate_evidence_size;
DROP TRIGGER IF EXISTS trg_set_resolved_date;
*/
