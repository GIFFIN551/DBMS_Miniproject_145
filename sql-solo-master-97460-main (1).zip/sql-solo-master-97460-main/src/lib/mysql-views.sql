-- ============================================
-- Crime Guard MySQL Views
-- ============================================
-- Pre-defined views for complex queries and reporting

-- ============================================
-- 1. COMPLETE CRIME REPORT VIEW
-- ============================================

CREATE OR REPLACE VIEW vw_complete_crime_reports AS
SELECT 
    cr.id,
    cr.report_number,
    cr.title,
    cr.description,
    cr.status,
    cr.priority,
    cr.incident_date,
    cr.reported_date,
    cr.resolved_date,
    cr.is_anonymous,
    cr.witness_count,
    cr.evidence_count,
    -- Reporter information
    u.id as reporter_id,
    u.full_name as reporter_name,
    u.email as reporter_email,
    u.phone as reporter_phone,
    -- Category information
    cc.id as category_id,
    cc.name as category_name,
    cc.severity_level,
    cc.color_code,
    -- Location information
    l.id as location_id,
    l.address,
    l.city,
    l.state,
    l.country,
    l.postal_code,
    l.latitude,
    l.longitude,
    -- Officer information
    officer.id as officer_id,
    officer.full_name as officer_name,
    officer.email as officer_email,
    -- Calculated fields
    DATEDIFF(CURRENT_DATE, DATE(cr.reported_date)) as days_since_report,
    CASE 
        WHEN cr.resolved_date IS NOT NULL 
        THEN TIMESTAMPDIFF(HOUR, cr.reported_date, cr.resolved_date)
        ELSE NULL 
    END as resolution_time_hours,
    CASE
        WHEN cr.status = 'resolved' THEN 'Closed'
        WHEN cr.status = 'investigating' THEN 'In Progress'
        WHEN cr.status = 'pending' THEN 'Awaiting Review'
        ELSE cr.status
    END as status_display
FROM crime_reports cr
INNER JOIN users u ON cr.user_id = u.id
INNER JOIN crime_categories cc ON cr.category_id = cc.id
INNER JOIN locations l ON cr.location_id = l.id
LEFT JOIN users officer ON cr.assigned_officer_id = officer.id;

-- ============================================
-- 2. PENDING REPORTS VIEW
-- ============================================

CREATE OR REPLACE VIEW vw_pending_reports AS
SELECT 
    cr.id,
    cr.report_number,
    cr.title,
    cr.priority,
    cr.incident_date,
    cr.reported_date,
    cc.name as category,
    cc.severity_level,
    l.city,
    l.state,
    u.full_name as reporter,
    DATEDIFF(CURRENT_DATE, DATE(cr.reported_date)) as days_pending
FROM crime_reports cr
INNER JOIN users u ON cr.user_id = u.id
INNER JOIN crime_categories cc ON cr.category_id = cc.id
INNER JOIN locations l ON cr.location_id = l.id
WHERE cr.status = 'pending'
ORDER BY cr.priority DESC, cr.reported_date ASC;

-- ============================================
-- 3. OFFICER WORKLOAD VIEW
-- ============================================

CREATE OR REPLACE VIEW vw_officer_workload AS
SELECT 
    u.id as officer_id,
    u.full_name as officer_name,
    u.email,
    COUNT(cr.id) as total_active_cases,
    COUNT(CASE WHEN cr.priority = 'urgent' THEN 1 END) as urgent_cases,
    COUNT(CASE WHEN cr.priority = 'high' THEN 1 END) as high_priority_cases,
    COUNT(CASE WHEN cr.priority = 'medium' THEN 1 END) as medium_priority_cases,
    COUNT(CASE WHEN cr.priority = 'low' THEN 1 END) as low_priority_cases,
    AVG(DATEDIFF(CURRENT_DATE, DATE(cr.reported_date))) as avg_case_age_days,
    MIN(cr.reported_date) as oldest_case_date,
    MAX(cr.reported_date) as newest_case_date
FROM users u
LEFT JOIN crime_reports cr ON cr.assigned_officer_id = u.id 
    AND cr.status IN ('investigating', 'pending')
WHERE u.role = 'officer' AND u.is_verified = TRUE
GROUP BY u.id, u.full_name, u.email;

-- ============================================
-- 4. CRIME HOTSPOTS VIEW
-- ============================================

CREATE OR REPLACE VIEW vw_crime_hotspots AS
SELECT 
    l.city,
    l.state,
    COUNT(cr.id) as total_crimes,
    COUNT(CASE WHEN cc.severity_level = 'critical' THEN 1 END) as critical_crimes,
    COUNT(CASE WHEN cc.severity_level = 'high' THEN 1 END) as high_severity_crimes,
    COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) as resolved_crimes,
    ROUND(COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) * 100.0 / COUNT(cr.id), 2) as resolution_rate,
    GROUP_CONCAT(DISTINCT cc.name ORDER BY cc.name SEPARATOR ', ') as common_crime_types
FROM crime_reports cr
INNER JOIN locations l ON cr.location_id = l.id
INNER JOIN crime_categories cc ON cr.category_id = cc.id
WHERE cr.incident_date >= DATE_SUB(CURRENT_DATE, INTERVAL 90 DAY)
GROUP BY l.city, l.state
HAVING total_crimes >= 5
ORDER BY total_crimes DESC;

-- ============================================
-- 5. CATEGORY STATISTICS VIEW
-- ============================================

CREATE OR REPLACE VIEW vw_category_statistics AS
SELECT 
    cc.id as category_id,
    cc.name as category_name,
    cc.severity_level,
    cc.color_code,
    COUNT(cr.id) as total_reports,
    COUNT(CASE WHEN cr.status = 'pending' THEN 1 END) as pending_count,
    COUNT(CASE WHEN cr.status = 'investigating' THEN 1 END) as investigating_count,
    COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) as resolved_count,
    COUNT(CASE WHEN cr.priority = 'urgent' THEN 1 END) as urgent_count,
    ROUND(COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) * 100.0 / 
          NULLIF(COUNT(cr.id), 0), 2) as resolution_rate,
    AVG(CASE 
        WHEN cr.status = 'resolved' AND cr.resolved_date IS NOT NULL 
        THEN TIMESTAMPDIFF(HOUR, cr.reported_date, cr.resolved_date)
    END) as avg_resolution_hours
FROM crime_categories cc
LEFT JOIN crime_reports cr ON cr.category_id = cc.id
    AND cr.incident_date >= DATE_SUB(CURRENT_DATE, INTERVAL 180 DAY)
WHERE cc.is_active = TRUE
GROUP BY cc.id, cc.name, cc.severity_level, cc.color_code;

-- ============================================
-- 6. MONTHLY TREND VIEW
-- ============================================

CREATE OR REPLACE VIEW vw_monthly_trends AS
SELECT 
    DATE_FORMAT(cr.incident_date, '%Y-%m') as month,
    COUNT(cr.id) as total_reports,
    COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) as resolved_reports,
    COUNT(CASE WHEN cr.priority = 'urgent' THEN 1 END) as urgent_reports,
    COUNT(CASE WHEN cr.priority = 'high' THEN 1 END) as high_priority_reports,
    COUNT(DISTINCT cr.user_id) as unique_reporters,
    COUNT(DISTINCT cr.category_id) as categories_reported,
    COUNT(DISTINCT l.city) as cities_affected,
    AVG(CASE 
        WHEN cr.status = 'resolved' AND cr.resolved_date IS NOT NULL 
        THEN TIMESTAMPDIFF(HOUR, cr.reported_date, cr.resolved_date)
    END) as avg_resolution_hours
FROM crime_reports cr
INNER JOIN locations l ON cr.location_id = l.id
WHERE cr.incident_date >= DATE_SUB(CURRENT_DATE, INTERVAL 12 MONTH)
GROUP BY DATE_FORMAT(cr.incident_date, '%Y-%m')
ORDER BY month DESC;

-- ============================================
-- 7. EVIDENCE SUMMARY VIEW
-- ============================================

CREATE OR REPLACE VIEW vw_evidence_summary AS
SELECT 
    cr.id as report_id,
    cr.report_number,
    cr.title,
    COUNT(e.id) as total_evidence,
    COUNT(CASE WHEN e.evidence_type = 'photo' THEN 1 END) as photo_count,
    COUNT(CASE WHEN e.evidence_type = 'video' THEN 1 END) as video_count,
    COUNT(CASE WHEN e.evidence_type = 'document' THEN 1 END) as document_count,
    COUNT(CASE WHEN e.evidence_type = 'audio' THEN 1 END) as audio_count,
    SUM(e.file_size) as total_size_bytes,
    ROUND(SUM(e.file_size) / 1024 / 1024, 2) as total_size_mb,
    MAX(e.uploaded_at) as latest_evidence_date
FROM crime_reports cr
LEFT JOIN evidence e ON e.crime_report_id = cr.id
GROUP BY cr.id, cr.report_number, cr.title;

-- ============================================
-- 8. WITNESS INFORMATION VIEW
-- ============================================

CREATE OR REPLACE VIEW vw_witness_information AS
SELECT 
    cr.id as report_id,
    cr.report_number,
    cr.title,
    cr.status,
    COUNT(w.id) as total_witnesses,
    COUNT(CASE WHEN w.is_anonymous = FALSE THEN 1 END) as identified_witnesses,
    COUNT(CASE WHEN w.contacted = TRUE THEN 1 END) as contacted_witnesses,
    COUNT(CASE WHEN w.contacted = FALSE THEN 1 END) as pending_contact,
    GROUP_CONCAT(
        CASE WHEN w.is_anonymous = FALSE 
        THEN w.full_name 
        ELSE 'Anonymous' 
        END 
        ORDER BY w.created_at 
        SEPARATOR ', '
    ) as witness_list
FROM crime_reports cr
LEFT JOIN witnesses w ON w.crime_report_id = cr.id
GROUP BY cr.id, cr.report_number, cr.title, cr.status;

-- ============================================
-- 9. RECENT ACTIVITY VIEW
-- ============================================

CREATE OR REPLACE VIEW vw_recent_activity AS
SELECT 
    cu.id,
    cu.crime_report_id,
    cr.report_number,
    cr.title as report_title,
    cu.update_type,
    cu.content,
    cu.is_public,
    cu.created_at,
    u.full_name as user_name,
    u.role as user_role,
    cc.name as category_name,
    l.city
FROM crime_updates cu
INNER JOIN crime_reports cr ON cu.crime_report_id = cr.id
INNER JOIN users u ON cu.user_id = u.id
INNER JOIN crime_categories cc ON cr.category_id = cc.id
INNER JOIN locations l ON cr.location_id = l.id
WHERE cu.created_at >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 7 DAY)
ORDER BY cu.created_at DESC;

-- ============================================
-- 10. USER NOTIFICATIONS VIEW
-- ============================================

CREATE OR REPLACE VIEW vw_user_notifications AS
SELECT 
    n.id,
    n.user_id,
    u.full_name as user_name,
    n.title,
    n.message,
    n.notification_type,
    n.is_read,
    n.created_at,
    cr.report_number,
    cr.status as report_status,
    CASE 
        WHEN n.is_read = TRUE THEN 'Read'
        ELSE 'Unread'
    END as read_status,
    TIMESTAMPDIFF(MINUTE, n.created_at, CURRENT_TIMESTAMP) as minutes_ago
FROM notifications n
INNER JOIN users u ON n.user_id = u.id
LEFT JOIN crime_reports cr ON n.crime_report_id = cr.id
WHERE n.created_at >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 30 DAY);

-- ============================================
-- 11. GEOGRAPHIC DISTRIBUTION VIEW
-- ============================================

CREATE OR REPLACE VIEW vw_geographic_distribution AS
SELECT 
    l.state,
    l.city,
    COUNT(cr.id) as total_reports,
    COUNT(DISTINCT cr.category_id) as unique_categories,
    COUNT(CASE WHEN cr.status = 'pending' THEN 1 END) as pending,
    COUNT(CASE WHEN cr.status = 'investigating' THEN 1 END) as investigating,
    COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) as resolved,
    AVG(l.latitude) as avg_latitude,
    AVG(l.longitude) as avg_longitude,
    GROUP_CONCAT(DISTINCT cc.name ORDER BY cc.name SEPARATOR ', ') as crime_types
FROM locations l
INNER JOIN crime_reports cr ON cr.location_id = l.id
INNER JOIN crime_categories cc ON cr.category_id = cc.id
GROUP BY l.state, l.city
ORDER BY total_reports DESC;

-- ============================================
-- 12. PERFORMANCE METRICS VIEW
-- ============================================

CREATE OR REPLACE VIEW vw_performance_metrics AS
SELECT 
    DATE(cr.reported_date) as report_date,
    COUNT(cr.id) as total_reports,
    COUNT(CASE WHEN cr.assigned_officer_id IS NOT NULL THEN 1 END) as assigned_reports,
    COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) as resolved_reports,
    AVG(CASE 
        WHEN cr.assigned_officer_id IS NOT NULL 
        THEN TIMESTAMPDIFF(HOUR, cr.reported_date, cr.updated_at)
    END) as avg_assignment_hours,
    AVG(CASE 
        WHEN cr.status = 'resolved' AND cr.resolved_date IS NOT NULL 
        THEN TIMESTAMPDIFF(HOUR, cr.reported_date, cr.resolved_date)
    END) as avg_resolution_hours,
    ROUND(COUNT(CASE WHEN cr.status = 'resolved' THEN 1 END) * 100.0 / 
          COUNT(cr.id), 2) as daily_resolution_rate
FROM crime_reports cr
WHERE cr.reported_date >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
GROUP BY DATE(cr.reported_date)
ORDER BY report_date DESC;

-- ============================================
-- EXAMPLE VIEW QUERIES
-- ============================================

-- Query complete report information
/*
SELECT * FROM vw_complete_crime_reports 
WHERE status = 'pending' 
ORDER BY priority DESC, reported_date ASC
LIMIT 10;
*/

-- Get officer workload
/*
SELECT * FROM vw_officer_workload
ORDER BY total_active_cases DESC;
*/

-- Find crime hotspots
/*
SELECT * FROM vw_crime_hotspots
WHERE total_crimes > 10
ORDER BY critical_crimes DESC, total_crimes DESC;
*/

-- View monthly trends
/*
SELECT * FROM vw_monthly_trends
ORDER BY month DESC
LIMIT 12;
*/

-- Check recent activity
/*
SELECT * FROM vw_recent_activity
WHERE is_public = TRUE
LIMIT 20;
*/
