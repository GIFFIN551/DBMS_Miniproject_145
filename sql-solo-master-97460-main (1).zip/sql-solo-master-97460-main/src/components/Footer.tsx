import { Shield, Database } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="border-t border-border bg-card mt-20">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 text-primary" />
            <div>
              <p className="font-semibold text-foreground">Crime Guard</p>
              <p className="text-sm text-muted-foreground">MySQL-Powered Safety Platform</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Database className="w-4 h-4 text-primary" />
            <span>Secured with MySQL Database</span>
          </div>
          
          <p className="text-sm text-muted-foreground">
            © 2024 Crime Guard. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};
