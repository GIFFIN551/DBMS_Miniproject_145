import { AlertTriangle, FileText, MapPin, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";

export const Hero = () => {
  const navigate = useNavigate();
  const stats = [
    { icon: FileText, label: "Total Reports", value: "1,247", color: "text-primary" },
    { icon: AlertTriangle, label: "Active Cases", value: "245", color: "text-accent" },
    { icon: TrendingUp, label: "Resolved", value: "1,002", color: "text-success" },
    { icon: MapPin, label: "Locations", value: "48", color: "text-warning" }
  ];

  return (
    <section className="relative py-20 px-4 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background to-card pointer-events-none" />
      
      <div className="container mx-auto relative z-10">
        <div className="max-w-4xl mx-auto text-center mb-12 animate-fade-in">
          <h2 className="text-5xl md:text-6xl font-bold mb-6 text-gradient">
            Keeping Communities Safe
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Report, track, and monitor crime incidents in real-time. Join thousands making a difference in community safety with MySQL-powered data management.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="text-base px-8 shadow-glow" onClick={() => document.getElementById('reports')?.scrollIntoView({ behavior: 'smooth' })}>
              <FileText className="w-5 h-5 mr-2" />
              Report a Crime
            </Button>
            <Button size="lg" variant="outline" className="text-base px-8" onClick={() => navigate('/map')}>
              <MapPin className="w-5 h-5 mr-2" />
              View Crime Map
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card 
                key={stat.label} 
                className="p-6 hover:shadow-lg transition-all duration-300 border-border bg-card animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-3 rounded-lg bg-muted ${stat.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                </div>
                <div>
                  <p className="text-3xl font-bold text-foreground mb-1">{stat.value}</p>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};
