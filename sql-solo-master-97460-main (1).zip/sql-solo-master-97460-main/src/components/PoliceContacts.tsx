import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Phone, Mail, MapPin, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";

const officers = [
  {
    id: 1,
    name: "Chief Michael Rodriguez",
    rank: "Chief of Police",
    department: "Central District",
    phone: "+1 (555) 100-1001",
    email: "m.rodriguez@police.gov",
    location: "Main Police Station, Downtown",
    availability: "Mon-Fri, 9:00 AM - 5:00 PM"
  },
  {
    id: 2,
    name: "Lt. Sarah Johnson",
    rank: "Lieutenant",
    department: "Crime Investigation Unit",
    phone: "+1 (555) 100-1002",
    email: "s.johnson@police.gov",
    location: "Investigation Bureau, 2nd Floor",
    availability: "24/7 Emergency Line"
  },
  {
    id: 3,
    name: "Sgt. David Chen",
    rank: "Sergeant",
    department: "Community Relations",
    phone: "+1 (555) 100-1003",
    email: "d.chen@police.gov",
    location: "Community Outreach Center",
    availability: "Mon-Sat, 8:00 AM - 6:00 PM"
  },
  {
    id: 4,
    name: "Officer Emma Williams",
    rank: "Officer",
    department: "Patrol Division",
    phone: "+1 (555) 100-1004",
    email: "e.williams@police.gov",
    location: "North Precinct",
    availability: "24/7 Patrol Duty"
  }
];

export const PoliceContacts = () => {
  return (
    <section className="py-16 px-4 bg-muted/50" id="contacts">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-3 rounded-full bg-primary/10 mb-4">
            <Shield className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-3xl font-bold mb-4">Contact Police Officers</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Reach out to our dedicated law enforcement team for assistance, inquiries, or emergency support
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {officers.map((officer) => (
            <Card key={officer.id} className="hover:shadow-lg transition-all duration-300">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-xl mb-1">{officer.name}</CardTitle>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        {officer.rank}
                      </Badge>
                      <span className="text-sm text-muted-foreground">{officer.department}</span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-sm">
                    <Phone className="w-4 h-4 text-primary" />
                    <a href={`tel:${officer.phone}`} className="hover:text-primary transition-colors">
                      {officer.phone}
                    </a>
                  </div>
                  
                  <div className="flex items-center gap-3 text-sm">
                    <Mail className="w-4 h-4 text-primary" />
                    <a href={`mailto:${officer.email}`} className="hover:text-primary transition-colors">
                      {officer.email}
                    </a>
                  </div>
                  
                  <div className="flex items-start gap-3 text-sm">
                    <MapPin className="w-4 h-4 text-primary mt-0.5" />
                    <span className="text-muted-foreground">{officer.location}</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-border">
                  <p className="text-xs text-muted-foreground mb-3">
                    <span className="font-medium">Availability:</span> {officer.availability}
                  </p>
                  <div className="flex gap-2">
                    <Button size="sm" className="flex-1" asChild>
                      <a href={`tel:${officer.phone}`}>Call</a>
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1" asChild>
                      <a href={`mailto:${officer.email}`}>Email</a>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-8 p-6 rounded-lg bg-destructive/10 border border-destructive/20">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-destructive mt-0.5" />
            <div>
              <h3 className="font-semibold text-destructive mb-1">Emergency Services</h3>
              <p className="text-sm text-muted-foreground mb-2">
                For immediate emergency assistance, please call 911 or your local emergency number
              </p>
              <Button variant="destructive" size="sm" asChild>
                <a href="tel:911">Call 911 - Emergency</a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
