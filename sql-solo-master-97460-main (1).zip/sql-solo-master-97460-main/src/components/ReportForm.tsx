import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { api, CrimeReport } from "@/lib/api";
import { AlertCircle, CheckCircle, FileText } from "lucide-react";

export const ReportForm = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    categoryId: "",
    address: "",
    city: "",
    state: "",
    incidentDate: "",
    priority: "medium",
    isAnonymous: false,
    email: "",
    phone: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Create location first
      const location = await api.createLocation({
        address: formData.address,
        city: formData.city,
        state: formData.state,
        country: "USA",
        postalCode: ""
      });

      // Create crime report
      const report: Omit<CrimeReport, 'id' | 'reportNumber'> = {
        userId: 1, // Replace with actual user ID from auth
        categoryId: parseInt(formData.categoryId),
        locationId: location.id!,
        title: formData.title,
        description: formData.description,
        status: 'pending',
        priority: formData.priority as any,
        incidentDate: formData.incidentDate,
        isAnonymous: formData.isAnonymous
      };

      const newReport = await api.createCrimeReport(report);

      // Invalidate queries to refresh the reports list and map
      queryClient.invalidateQueries({ queryKey: ['crime-reports'] });

      toast({
        title: "Report Submitted Successfully",
        description: `Your report ${newReport.reportNumber} has been submitted and is being reviewed.`,
        action: <CheckCircle className="w-5 h-5 text-success" />
      });

      // Reset form
      setFormData({
        title: "",
        description: "",
        categoryId: "",
        address: "",
        city: "",
        state: "",
        incidentDate: "",
        priority: "medium",
        isAnonymous: false,
        email: "",
        phone: ""
      });
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: "There was an error submitting your report. Please try again.",
        variant: "destructive",
        action: <AlertCircle className="w-5 h-5" />
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-16 px-4" id="reports">
      <div className="container mx-auto max-w-4xl">
        <Card className="border-border shadow-lg">
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-lg bg-primary/10">
                <FileText className="w-6 h-6 text-primary" />
              </div>
              <CardTitle className="text-2xl">Submit Crime Report</CardTitle>
            </div>
            <CardDescription>
              All information is securely stored in our MySQL database and encrypted for your protection
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Report Title *</Label>
                  <Input
                    id="title"
                    placeholder="Brief description of the incident"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Crime Category *</Label>
                  <Select 
                    value={formData.categoryId} 
                    onValueChange={(value) => setFormData({ ...formData, categoryId: value })}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">Theft</SelectItem>
                      <SelectItem value="2">Assault</SelectItem>
                      <SelectItem value="3">Vandalism</SelectItem>
                      <SelectItem value="4">Fraud</SelectItem>
                      <SelectItem value="5">Drug Related</SelectItem>
                      <SelectItem value="6">Cybercrime</SelectItem>
                      <SelectItem value="7">Domestic Violence</SelectItem>
                      <SelectItem value="8">Traffic Violation</SelectItem>
                      <SelectItem value="9">Robbery</SelectItem>
                      <SelectItem value="10">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+1 (555) 000-0000"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Detailed Description *</Label>
                <Textarea
                  id="description"
                  placeholder="Provide detailed information about the incident..."
                  rows={5}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                />
              </div>

              <div className="grid md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="address">Address *</Label>
                  <Input
                    id="address"
                    placeholder="Street address"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="city">City *</Label>
                  <Input
                    id="city"
                    placeholder="City"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="state">State *</Label>
                  <Input
                    id="state"
                    placeholder="State"
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="incidentDate">Incident Date & Time *</Label>
                  <Input
                    id="incidentDate"
                    type="datetime-local"
                    value={formData.incidentDate}
                    onChange={(e) => setFormData({ ...formData, incidentDate: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="priority">Priority Level</Label>
                  <Select 
                    value={formData.priority} 
                    onValueChange={(value) => setFormData({ ...formData, priority: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 rounded-lg bg-muted">
                <div className="space-y-0.5">
                  <Label htmlFor="anonymous">Submit Anonymously</Label>
                  <p className="text-sm text-muted-foreground">
                    Your identity will be kept confidential
                  </p>
                </div>
                <Switch
                  id="anonymous"
                  checked={formData.isAnonymous}
                  onCheckedChange={(checked) => setFormData({ ...formData, isAnonymous: checked })}
                />
              </div>

              <Button type="submit" size="lg" className="w-full" disabled={loading}>
                {loading ? "Submitting..." : "Submit Report"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};
