import { Shield, Menu, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export const Header = () => {
  const navigate = useNavigate();
  const [notifications] = useState([
    { id: 1, text: "New report submitted in your area", time: "5m ago" },
    { id: 2, text: "Report #CR-2024-001 updated to investigating", time: "1h ago" },
    { id: 3, text: "Your report has been resolved", time: "2h ago" }
  ]);
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-primary-glow shadow-glow">
            <Shield className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">Crime Guard</h1>
            <p className="text-xs text-muted-foreground">Community Safety Platform</p>
          </div>
        </div>
        
        <nav className="hidden md:flex items-center gap-6">
          <Link to="/" className="text-sm font-medium text-foreground hover:text-primary transition-colors">
            Dashboard
          </Link>
          <button 
            onClick={() => {
              navigate('/');
              setTimeout(() => document.getElementById('reports')?.scrollIntoView({ behavior: 'smooth' }), 100);
            }}
            className="text-sm font-medium text-foreground hover:text-primary transition-colors"
          >
            Reports
          </button>
          <Link to="/map" className="text-sm font-medium text-foreground hover:text-primary transition-colors">
            Crime Map
          </Link>
          <Link to="/statistics" className="text-sm font-medium text-foreground hover:text-primary transition-colors">
            Statistics
          </Link>
        </nav>

        <div className="flex items-center gap-3">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="w-5 h-5" />
                <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-accent text-[10px]">
                  {notifications.length}
                </Badge>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <div className="p-2 font-semibold border-b border-border">Notifications</div>
              {notifications.map((notification) => (
                <DropdownMenuItem key={notification.id} className="flex flex-col items-start p-3 cursor-pointer">
                  <span className="text-sm">{notification.text}</span>
                  <span className="text-xs text-muted-foreground">{notification.time}</span>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button 
            variant="default" 
            size="sm" 
            className="hidden sm:flex"
            onClick={() => {
              navigate('/');
              setTimeout(() => document.getElementById('reports')?.scrollIntoView({ behavior: 'smooth' }), 100);
            }}
          >
            Report Crime
          </Button>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px]">
              <nav className="flex flex-col gap-4 mt-8">
                <Link to="/" className="text-lg font-medium text-foreground hover:text-primary transition-colors p-2">
                  Dashboard
                </Link>
                <button 
                  onClick={() => {
                    navigate('/');
                    setTimeout(() => document.getElementById('reports')?.scrollIntoView({ behavior: 'smooth' }), 100);
                  }}
                  className="text-lg font-medium text-foreground hover:text-primary transition-colors p-2 text-left"
                >
                  Reports
                </button>
                <Link to="/map" className="text-lg font-medium text-foreground hover:text-primary transition-colors p-2">
                  Crime Map
                </Link>
                <Link to="/statistics" className="text-lg font-medium text-foreground hover:text-primary transition-colors p-2">
                  Statistics
                </Link>
                <Button 
                  variant="default" 
                  className="mt-4"
                  onClick={() => {
                    navigate('/');
                    setTimeout(() => document.getElementById('reports')?.scrollIntoView({ behavior: 'smooth' }), 100);
                  }}
                >
                  Report Crime
                </Button>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};
