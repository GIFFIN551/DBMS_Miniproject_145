import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { api } from "@/lib/api";
import { Clock, MapPin, AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export const ReportsList = () => {
  const { data: reports, isLoading } = useQuery({
    queryKey: ['crime-reports'],
    queryFn: api.getCrimeReports
  });

  const getStatusColor = (status: string) => {
    const colors = {
      pending: 'bg-warning/10 text-warning border-warning/20',
      investigating: 'bg-primary/10 text-primary border-primary/20',
      resolved: 'bg-success/10 text-success border-success/20',
      closed: 'bg-muted text-muted-foreground border-border',
      rejected: 'bg-destructive/10 text-destructive border-destructive/20'
    };
    return colors[status as keyof typeof colors] || colors.pending;
  };

  const getPriorityColor = (priority: string) => {
    const colors = {
      low: 'bg-muted text-muted-foreground',
      medium: 'bg-primary/10 text-primary',
      high: 'bg-accent/10 text-accent',
      urgent: 'bg-destructive/10 text-destructive'
    };
    return colors[priority as keyof typeof colors] || colors.medium;
  };

  if (isLoading) {
    return (
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h3 className="text-2xl font-bold mb-8">Recent Reports</h3>
          <div className="grid gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-24 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 px-4" id="dashboard">
      <div className="container mx-auto max-w-6xl">
        <div className="flex items-center justify-between mb-8">
          <h3 className="text-2xl font-bold">Recent Crime Reports</h3>
          <Badge variant="outline" className="text-sm">
            {reports?.length || 0} Total Reports
          </Badge>
        </div>

        <div className="grid gap-6">
          {reports?.map((report) => (
            <Card key={report.id} className="hover:shadow-lg transition-all duration-300 border-border">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <CardTitle className="text-xl">{report.title}</CardTitle>
                      <Badge className={getPriorityColor(report.priority)}>
                        {report.priority}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {new Date(report.incidentDate).toLocaleDateString()}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        Location #{report.locationId}
                      </span>
                      <span className="font-mono text-xs">{report.reportNumber}</span>
                    </div>
                  </div>
                  <Badge className={getStatusColor(report.status)}>
                    {report.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">{report.description}</p>
                <div className="flex items-center gap-4 text-sm">
                  <span className="flex items-center gap-1.5 text-muted-foreground">
                    <AlertCircle className="w-4 h-4" />
                    {report.witnessCount || 0} witnesses
                  </span>
                  <span className="text-muted-foreground">
                    {report.evidenceCount || 0} evidence files
                  </span>
                  {report.isAnonymous && (
                    <Badge variant="outline" className="text-xs">
                      Anonymous
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
