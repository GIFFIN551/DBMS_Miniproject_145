import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, AlertTriangle, Shield, Navigation, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

const CrimeMap = () => {
  // Fetch crime reports and locations
  const { data: reports, isLoading: reportsLoading } = useQuery({
    queryKey: ['crime-reports'],
    queryFn: api.getCrimeReports
  });

  const { data: locations, isLoading: locationsLoading } = useQuery({
    queryKey: ['locations'],
    queryFn: api.getLocations
  });

  const isLoading = reportsLoading || locationsLoading;

  // Combine reports with their locations
  const crimeLocations = reports?.map(report => {
    const location = locations?.find(loc => loc.id === report.locationId);
    return {
      ...report,
      location,
      lat: location?.latitude,
      lng: location?.longitude,
      type: report.title,
      severity: report.priority,
      address: location ? `${location.address}, ${location.city}, ${location.state}` : 'Unknown'
    };
  }).filter(r => r.lat && r.lng) || [];

  const getSeverityColor = (severity: string) => {
    const colors = {
      low: "bg-success/10 text-success border-success/20",
      medium: "bg-warning/10 text-warning border-warning/20",
      high: "bg-accent/10 text-accent border-accent/20",
      urgent: "bg-destructive/10 text-destructive border-destructive/20",
      critical: "bg-destructive/10 text-destructive border-destructive/20"
    };
    return colors[severity as keyof typeof colors] || colors.medium;
  };

  const getStatusColor = (status: string) => {
    const colors = {
      pending: 'bg-warning/10 text-warning border-warning/20',
      investigating: 'bg-primary/10 text-primary border-primary/20',
      resolved: 'bg-success/10 text-success border-success/20',
      closed: 'bg-muted text-muted-foreground border-border',
      rejected: 'bg-destructive/10 text-destructive border-destructive/20'
    };
    return colors[status as keyof typeof colors] || colors.pending;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="py-16 px-4">
          <div className="container mx-auto max-w-7xl">
            <Skeleton className="h-12 w-96 mb-8" />
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Skeleton className="h-[700px] w-full" />
              </div>
              <div>
                <Skeleton className="h-[700px] w-full" />
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="py-16 px-4">
        <div className="container mx-auto max-w-7xl">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-4xl font-bold mb-2 text-gradient">Crime Map</h1>
              <p className="text-muted-foreground">Real-time crime location tracking powered by MySQL geolocation data</p>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="text-sm">
                {crimeLocations.length} Active Reports
              </Badge>
              <Button className="shadow-glow">
                <Navigation className="w-4 h-4 mr-2" />
                Use My Location
              </Button>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Map Area */}
            <Card className="lg:col-span-2 border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-primary" />
                  Interactive Crime Map
                </CardTitle>
                <CardDescription>
                  Click on markers to view crime details. Data retrieved from MySQL locations table.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative w-full h-[600px] bg-muted rounded-lg overflow-hidden border-2 border-border">
                  {/* Map placeholder with visual elements */}
                  <div className="absolute inset-0 bg-gradient-to-br from-muted via-background to-muted">
                    {/* Grid overlay for map effect */}
                    <div className="absolute inset-0 opacity-20">
                      <div className="grid grid-cols-10 grid-rows-10 h-full w-full">
                        {Array.from({ length: 100 }).map((_, i) => (
                          <div key={i} className="border border-border/50" />
                        ))}
                      </div>
                    </div>
                    
                    {/* Crime markers */}
                    {crimeLocations.map((location, index) => (
                      <div
                        key={location.id}
                        className="absolute animate-fade-in hover:scale-110 transition-transform cursor-pointer group"
                        style={{
                          left: `${20 + index * 15}%`,
                          top: `${30 + (index % 3) * 20}%`,
                          animationDelay: `${index * 100}ms`
                        }}
                      >
                        <div className="relative">
                          <div className="absolute inset-0 bg-primary rounded-full blur-xl opacity-50 group-hover:opacity-75 transition-opacity" />
                          <AlertTriangle 
                            className={`w-8 h-8 relative z-10 ${
                              location.severity === 'urgent' ? 'text-destructive' :
                              location.severity === 'high' ? 'text-accent' :
                              location.severity === 'medium' ? 'text-warning' :
                              'text-success'
                            }`}
                          />
                        </div>
                        <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 bg-card border border-border rounded-lg p-3 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity min-w-[200px] z-20">
                          <p className="text-xs font-semibold mb-1">{location.type}</p>
                          <p className="text-xs text-muted-foreground mb-2">{location.address}</p>
                          <div className="flex gap-2 flex-wrap">
                            <Badge className={getSeverityColor(location.severity)} variant="outline">
                              {location.severity}
                            </Badge>
                            <Badge className={getStatusColor(location.status)} variant="outline">
                              {location.status}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-2">
                            <Clock className="w-3 h-3 inline mr-1" />
                            {new Date(location.incidentDate).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))}
                    
                    {/* Center marker for reference */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                      <Shield className="w-12 h-12 text-primary/20" />
                    </div>
                  </div>
                  
                  <div className="absolute bottom-4 left-4 bg-card/95 backdrop-blur border border-border rounded-lg p-3 shadow-lg">
                    <p className="text-xs font-semibold mb-2">Map Legend</p>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs">
                        <div className="w-3 h-3 rounded-full bg-destructive" />
                        <span>Critical</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <div className="w-3 h-3 rounded-full bg-accent" />
                        <span>High</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <div className="w-3 h-3 rounded-full bg-warning" />
                        <span>Medium</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <div className="w-3 h-3 rounded-full bg-success" />
                        <span>Low</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Location List */}
            <div className="space-y-4">
              <Card className="border-border">
                <CardHeader>
                  <CardTitle className="text-lg">Recent Locations</CardTitle>
                  <CardDescription>
                    SQL Query: SELECT * FROM locations INNER JOIN crime_reports
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3 max-h-[500px] overflow-y-auto">
                  {crimeLocations.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-4">No reports available</p>
                  ) : (
                    crimeLocations.map((location) => (
                      <Card key={location.id} className="p-4 hover:shadow-md transition-shadow cursor-pointer">
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4 text-primary flex-shrink-0" />
                            <span className="font-semibold text-sm">{location.type}</span>
                          </div>
                          <Badge className={getSeverityColor(location.severity)}>
                            {location.severity}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mb-2">{location.address}</p>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className={`${getStatusColor(location.status)} text-xs`}>
                            {location.status}
                          </Badge>
                          <span className="text-xs text-muted-foreground">{location.reportNumber}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Clock className="w-3 h-3" />
                          {new Date(location.incidentDate).toLocaleDateString()}
                        </div>
                        <div className="flex gap-2 mt-2 text-xs text-muted-foreground">
                          <span>Lat: {location.lat?.toFixed(4)}</span>
                          <span>Lng: {location.lng?.toFixed(4)}</span>
                        </div>
                      </Card>
                    ))
                  )}
                </CardContent>
              </Card>

              <Card className="border-border bg-primary/5">
                <CardHeader>
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    Database Info
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-xs space-y-2">
                  <p><strong>Table:</strong> locations</p>
                  <p><strong>Coordinates:</strong> latitude, longitude (DECIMAL)</p>
                  <p><strong>Indexes:</strong> idx_coordinates</p>
                  <p><strong>Total Locations:</strong> {crimeLocations.length}</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default CrimeMap;
