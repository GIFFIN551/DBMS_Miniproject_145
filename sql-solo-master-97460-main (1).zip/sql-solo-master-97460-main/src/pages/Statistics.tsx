import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Activity, Database, BarChart3, PieChart } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

const Statistics = () => {
  const { data: stats } = useQuery({
    queryKey: ['statistics'],
    queryFn: api.getStatistics
  });

  const { data: categories } = useQuery({
    queryKey: ['categories'],
    queryFn: api.getCrimeCategories
  });

  const monthlyData = [
    { month: "Jan", reports: 89, resolved: 67 },
    { month: "Feb", reports: 102, resolved: 85 },
    { month: "Mar", reports: 95, resolved: 78 },
    { month: "Apr", reports: 118, resolved: 94 },
    { month: "May", reports: 134, resolved: 112 },
    { month: "Jun", reports: 156, resolved: 128 }
  ];

  const cityStats = [
    { city: "New York", reports: 456, trend: 12 },
    { city: "Los Angeles", reports: 389, trend: -5 },
    { city: "Chicago", reports: 267, trend: 8 },
    { city: "Houston", reports: 198, trend: -3 },
    { city: "Phoenix", reports: 145, trend: 15 }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="py-16 px-4">
        <div className="container mx-auto max-w-7xl">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2 text-gradient">Crime Statistics</h1>
            <p className="text-muted-foreground">Comprehensive analytics and insights</p>
          </div>

          {/* Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="border-border hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-baseline justify-between">
                  <p className="text-3xl font-bold text-foreground">{stats?.totalReports || 0}</p>
                  <Badge className="bg-success/10 text-success">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    {stats?.reportsGrowth || 0}%
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Pending</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-baseline justify-between">
                  <p className="text-3xl font-bold text-warning">{stats?.pendingReports || 0}</p>
                  <Activity className="w-5 h-5 text-warning" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-border hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Investigating</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-baseline justify-between">
                  <p className="text-3xl font-bold text-primary">{stats?.investigatingReports || 0}</p>
                  <Activity className="w-5 h-5 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-border hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Resolved</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-baseline justify-between">
                  <p className="text-3xl font-bold text-success">{stats?.resolvedReports || 0}</p>
                  <Badge className="bg-success/10 text-success">80.4%</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts Section */}
          <div className="grid lg:grid-cols-2 gap-6 mb-8">
            {/* Monthly Trend */}
            <Card className="border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-primary" />
                  Monthly Trend
                </CardTitle>
                <CardDescription>
                  Reports vs Resolved - Last 6 Months
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {monthlyData.map((data) => (
                    <div key={data.month} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="font-medium">{data.month}</span>
                        <span className="text-muted-foreground">{data.reports} reports / {data.resolved} resolved</span>
                      </div>
                      <div className="flex gap-2 h-8">
                        <div 
                          className="bg-primary rounded transition-all hover:opacity-80"
                          style={{ width: `${(data.reports / 160) * 100}%` }}
                          title={`${data.reports} reports`}
                        />
                        <div 
                          className="bg-success rounded transition-all hover:opacity-80"
                          style={{ width: `${(data.resolved / 160) * 100}%` }}
                          title={`${data.resolved} resolved`}
                        />
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex gap-4 mt-6 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-primary rounded" />
                    <span>Reports</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-success rounded" />
                    <span>Resolved</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* City Statistics */}
            <Card className="border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="w-5 h-5 text-primary" />
                  City Breakdown
                </CardTitle>
                <CardDescription>
                  Reports by City
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {cityStats.map((city, index) => (
                    <div key={city.city} className="animate-fade-in" style={{ animationDelay: `${index * 50}ms` }}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">{city.city}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-muted-foreground">{city.reports}</span>
                          <Badge className={city.trend > 0 ? 'bg-destructive/10 text-destructive' : 'bg-success/10 text-success'}>
                            {city.trend > 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                            {Math.abs(city.trend)}%
                          </Badge>
                        </div>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full transition-all"
                          style={{ width: `${(city.reports / 456) * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Category Breakdown */}
          <Card className="border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5 text-primary" />
                Crime Categories Distribution
              </CardTitle>
              <CardDescription>
                Analysis by crime category
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {categories?.map((category) => (
                  <Card 
                    key={category.id} 
                    className="p-4 hover:shadow-md transition-all cursor-pointer border-border"
                    style={{ borderLeftWidth: '4px', borderLeftColor: category.colorCode }}
                  >
                    <div className="text-center">
                      <p className="text-2xl font-bold mb-1">{Math.floor(Math.random() * 150) + 50}</p>
                      <p className="text-xs font-medium mb-2">{category.name}</p>
                      <Badge 
                        className={
                          category.severityLevel === 'critical' ? 'bg-destructive/10 text-destructive' :
                          category.severityLevel === 'high' ? 'bg-accent/10 text-accent' :
                          category.severityLevel === 'medium' ? 'bg-warning/10 text-warning' :
                          'bg-success/10 text-success'
                        }
                      >
                        {category.severityLevel}
                      </Badge>
                    </div>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Statistics;
